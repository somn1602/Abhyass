// ===========================================================================
// Abhyaas — frontend logic
// Plain JavaScript, no frameworks, so every step is easy to follow.
// ===========================================================================

let SUBJECTS = [];   // will hold the data loaded from the backend

// --- 1. When the page loads, fetch the subjects from our Flask server ------
async function init() {
  try {
    const res = await fetch("/api/subjects");
    SUBJECTS = await res.json();
    renderSubjectList();
    fillQuestionPicker();
  } catch (e) {
    document.getElementById("subject-list").innerHTML =
      "<p class='hint'>Could not load subjects. Is the server running?</p>";
  }
}

// --- 2. Tab switching (Learn / Evaluate) -----------------------------------
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("is-active"));
    document.querySelectorAll(".view").forEach((v) => v.classList.remove("is-active"));
    tab.classList.add("is-active");
    document.getElementById("view-" + tab.dataset.view).classList.add("is-active");
  });
});

// --- 3. LEARN: list of subjects in the sidebar -----------------------------
function renderSubjectList() {
  const list = document.getElementById("subject-list");
  list.innerHTML = "";
  SUBJECTS.forEach((subject) => {
    const btn = document.createElement("button");
    btn.className = "subject-btn";
    btn.innerHTML = `<div class="s-name">${subject.name}</div>
                     <div class="s-paper">${subject.paper}</div>`;
    btn.addEventListener("click", () => {
      document.querySelectorAll(".subject-btn").forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");
      showSubject(subject);
    });
    list.appendChild(btn);
  });
}

// --- 4. LEARN: show one subject's topics -----------------------------------
function showSubject(subject) {
  const area = document.getElementById("topic-area");
  let html = `<div class="subject-heading">
                <h2>${subject.name}</h2>
                <p>${subject.description}</p>
              </div>`;
  subject.topics.forEach((topic) => {
    html += `<div class="topic-card">
               <h3>${topic.title}</h3>
               <p>${topic.notes}</p>
             </div>`;
  });
  area.innerHTML = html;
}

// --- 5. EVALUATE: fill the dropdown with all practice questions ------------
function fillQuestionPicker() {
  const picker = document.getElementById("question-picker");
  SUBJECTS.forEach((subject) => {
    (subject.practiceQuestions || []).forEach((q) => {
      const opt = document.createElement("option");
      opt.value = JSON.stringify(q);           // store the whole question object
      opt.textContent = `[${subject.name}] ${q.question}`;
      picker.appendChild(opt);
    });
  });
}

// When a question is picked from the dropdown, drop it into the text box.
document.getElementById("question-picker").addEventListener("change", (e) => {
  if (!e.target.value) return;
  const q = JSON.parse(e.target.value);
  document.getElementById("question").value = q.question;
  document.getElementById("question").dataset.wordLimit = q.wordLimit || 250;
});

// --- 6. EVALUATE: live word counter ----------------------------------------
const answerBox = document.getElementById("answer");
answerBox.addEventListener("input", () => {
  const words = answerBox.value.trim().split(/\s+/).filter(Boolean).length;
  const el = document.getElementById("word-count");
  el.textContent = words + " words";
  const limit = Number(document.getElementById("question").dataset.wordLimit || 250);
  el.classList.toggle("over", words > limit + 30);
});

// --- 7. EVALUATE: send the answer to the AI and show the result ------------
document.getElementById("evaluate-btn").addEventListener("click", async () => {
  const question = document.getElementById("question").value.trim();
  const answer = document.getElementById("answer").value.trim();
  const wordLimit = Number(document.getElementById("question").dataset.wordLimit || 250);
  const result = document.getElementById("result");
  const btn = document.getElementById("evaluate-btn");

  if (!question || !answer) {
    result.innerHTML = `<div class="error-box">Please add both a question and your answer.</div>`;
    return;
  }

  btn.disabled = true;
  btn.textContent = "Evaluating…";
  result.innerHTML = `<div class="loading">The examiner is reading your answer…</div>`;

  try {
    const res = await fetch("/api/evaluate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, answer, wordLimit }),
    });
    const data = await res.json();

    if (data.error) {
      result.innerHTML = `<div class="error-box">${data.error}</div>`;
    } else {
      renderResult(data);
    }
  } catch (e) {
    result.innerHTML = `<div class="error-box">Could not reach the server. Try again.</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Evaluate my answer";
  }
});

// --- 8. EVALUATE: turn the AI's JSON into a nice display --------------------
function evaluationHtml(d) {
  const s = d.scores || {};
  const scoreItems = Object.keys(s).map((key) => `
    <div class="score-item">
      <div class="label">${key}</div>
      <div class="bar"><span style="width:${(s[key] / 10) * 100}%"></span></div>
      <div class="val">${s[key]} / 10</div>
    </div>`).join("");

  const listBlock = (title, items, cls) => {
    if (!items || !items.length) return "";
    return `<div class="feedback-block ${cls}">
              <h4>${title}</h4>
              <ul>${items.map((i) => `<li>${i}</li>`).join("")}</ul>
            </div>`;
  };

  return `
    <div class="score-banner">
      <div class="big">${d.total}</div>
      <div class="out">/ 40</div>
      <div class="verdict">${d.verdict || ""}</div>
    </div>
    <div class="score-grid">${scoreItems}</div>
    ${listBlock("What worked", d.strengths, "strengths")}
    ${listBlock("How to improve", d.improvements, "improve")}
    ${listBlock("Points you missed", d.missing_points, "missing")}
  `;
}

function renderResult(d) {
  document.getElementById("result").innerHTML = evaluationHtml(d);
}

function renderResultInto(el, d) {
  el.innerHTML = evaluationHtml(d);
}

// --- 9. ASK: send input to the orchestrator, show which agent replied ------
document.getElementById("ask-btn").addEventListener("click", async () => {
  const input = document.getElementById("ask-input").value.trim();
  const box = document.getElementById("ask-result");
  const btn = document.getElementById("ask-btn");

  if (!input) {
    box.innerHTML = `<div class="error-box">Type a question first.</div>`;
    return;
  }

  btn.disabled = true;
  btn.textContent = "Thinking…";
  box.innerHTML = `<div class="loading">Routing to the right agent…</div>`;

  try {
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input }),
    });
    const payload = await res.json();

    if (payload.error) {
      box.innerHTML = `<div class="error-box">${payload.error}</div>`;
    } else {
      renderAgentResponse(box, payload);
    }
  } catch (e) {
    box.innerHTML = `<div class="error-box">Could not reach the server.</div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Ask";
  }
});

// Show a badge for the chosen agent, then its answer (depends on data.type).
function renderAgentResponse(box, payload) {
  const badge = `<div class="agent-badge">Handled by: <strong>${payload.agent_label}</strong></div>`;
  const d = payload.data || {};

  if (d.type === "evaluation") {
    box.innerHTML = badge;
    const holder = document.createElement("div");
    box.appendChild(holder);
    renderResultInto(holder, d);
  } else if (d.type === "mcq") {
    box.innerHTML = badge + renderMCQ(d.questions || []);
    wireMCQ();
  } else {
    // plain-text agents (tutor, current affairs)
    box.innerHTML = badge + `<div class="feedback-block">
        <h4>${d.title || "Answer"}</h4>
        <div class="text-body">${escapeHtml(d.body || "").replace(/\n/g, "<br>")}</div>
      </div>`;
  }
}

function renderMCQ(questions) {
  return questions.map((q, i) => `
    <div class="mcq-card" data-answer="${q.answer_index}">
      <p class="mcq-q"><strong>Q${i + 1}.</strong> ${escapeHtml(q.question)}</p>
      <div class="mcq-options">
        ${q.options.map((opt, j) =>
          `<button class="mcq-opt" data-i="${j}">${String.fromCharCode(65 + j)}. ${escapeHtml(opt)}</button>`
        ).join("")}
      </div>
      <p class="mcq-explain" hidden>${escapeHtml(q.explanation || "")}</p>
    </div>`).join("");
}

// Reveal correct/wrong when an option is clicked.
function wireMCQ() {
  document.querySelectorAll(".mcq-card").forEach((card) => {
    const correct = Number(card.dataset.answer);
    card.querySelectorAll(".mcq-opt").forEach((btn) => {
      btn.addEventListener("click", () => {
        card.querySelectorAll(".mcq-opt").forEach((b) => b.disabled = true);
        const picked = Number(btn.dataset.i);
        card.querySelectorAll(".mcq-opt")[correct].classList.add("correct");
        if (picked !== correct) btn.classList.add("wrong");
        card.querySelector(".mcq-explain").hidden = false;
      });
    });
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// Start everything
init();
