"""
Shared AI helper for all agents.

Every agent is the SAME Gemini model — the difference is the "role" (system
instruction) we give it. This one file is the only place that actually talks
to Gemini, so all agents stay consistent and simple.
"""

import os
import json

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
if API_KEY:
    genai.configure(api_key=API_KEY)

# If this model name ever stops working, check https://ai.google.dev
MODEL_NAME = "gemini-2.0-flash"


def ask_gemini(role, user_content, expect_json=False):
    """
    Ask Gemini something.
      role          -> the agent's job/personality (system instruction)
      user_content  -> the actual request
      expect_json   -> if True, parse the reply as JSON and return a dict
    """
    if not API_KEY:
        raise RuntimeError(
            "No API key found. Add GEMINI_API_KEY to your .env file (see README.md)."
        )

    model = genai.GenerativeModel(MODEL_NAME, system_instruction=role)
    response = model.generate_content(user_content)
    text = response.text.strip()

    if not expect_json:
        return text

    # Models sometimes wrap JSON in ```json ... ``` fences — strip them.
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    return json.loads(text.strip())
