"""
MCQ agent — generates UPSC Prelims-style multiple-choice questions on a topic.
"""

from .gemini_client import ask_gemini

ROLE = (
    "You are a UPSC Prelims question setter. You write factually accurate, "
    "exam-standard multiple-choice questions with four options each."
)


def handle(user_input, count=5):
    """Return {type, questions:[{question, options[], answer_index, explanation}]}."""
    prompt = f"""
Create {count} UPSC Prelims-style multiple-choice questions on: {user_input}

Reply with ONLY this JSON:
{{
  "questions": [
    {{
      "question": "the question text",
      "options": ["option A", "option B", "option C", "option D"],
      "answer_index": 0,
      "explanation": "why the correct option is right, in one or two lines"
    }}
  ]
}}
"answer_index" is the 0-based position of the correct option.
"""
    result = ask_gemini(ROLE, prompt, expect_json=True)
    result["type"] = "mcq"
    return result
