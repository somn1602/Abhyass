"""
Tutor agent — explains a concept or clears a doubt, UPSC-style.
"""

from .gemini_client import ask_gemini

ROLE = (
    "You are a patient UPSC mentor. You explain concepts clearly and concisely "
    "for Civil Services aspirants: link the topic to the GS syllabus, give the "
    "key points an answer would need, and add one relevant example or case where "
    "useful. Keep it focused — no filler."
)


def handle(user_input):
    """Return a plain-text explanation."""
    text = ask_gemini(ROLE, user_input)
    return {"type": "text", "title": "Explanation", "body": text}
