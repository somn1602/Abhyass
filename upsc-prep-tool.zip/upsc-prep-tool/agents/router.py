"""
Router (orchestrator) agent.

It does NOT answer the aspirant. Its only job is to read the input and decide
which specialist agent should handle it.
"""

from .gemini_client import ask_gemini

ROLE = (
    "You are the router for a UPSC preparation assistant. "
    "You never answer the question yourself — you only decide which specialist "
    "agent should handle the user's request."
)


def route(user_input):
    """Return e.g. {"agent": "tutor", "reason": "..."}."""
    prompt = f"""
A UPSC aspirant sent this message:
"{user_input}"

Pick the single best agent to handle it:
- "evaluator": the user has WRITTEN an answer and wants it graded or reviewed.
- "tutor": the user wants a concept explained, or has a doubt/question to understand a topic.
- "mcq": the user wants practice multiple-choice (Prelims) questions on a topic.
- "current_affairs": the user asks about current affairs, news, or wants to link an event to the syllabus.

Reply with ONLY this JSON, nothing else:
{{"agent": "evaluator | tutor | mcq | current_affairs", "reason": "one short line"}}
"""
    try:
        result = ask_gemini(ROLE, prompt, expect_json=True)
        # Safety net: if the model returns an unknown label, fall back to tutor.
        if result.get("agent") not in {"evaluator", "tutor", "mcq", "current_affairs"}:
            result = {"agent": "tutor", "reason": "defaulted"}
        return result
    except Exception:
        return {"agent": "tutor", "reason": "router fallback"}
