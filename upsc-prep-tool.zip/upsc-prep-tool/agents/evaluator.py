"""
Evaluator agent — grades a UPSC Mains-style answer like a real examiner.
Used both by the structured "Evaluate" tab and by the router.
"""

from .gemini_client import ask_gemini

ROLE = (
    "You are an experienced UPSC Mains examiner. You mark answers strictly but "
    "fairly, exactly the way the real Civil Services examination is graded."
)


def evaluate(question, answer, word_limit=250):
    """Return structured feedback: scores, strengths, improvements, etc."""
    word_count = len(answer.split())

    prompt = f"""
QUESTION:
{question}

WORD LIMIT: {word_limit} words
CANDIDATE'S ANSWER (word count: {word_count}):
{answer}

Score the answer out of 10 on each parameter:
- content: relevance, accuracy, depth, coverage of the question's demand
- structure: clear introduction, organised body, and conclusion
- coverage: whether all dimensions/keywords the question demands are addressed
- presentation: clarity, flow, examples, and respect for the word limit

Reply with ONLY this JSON:
{{
  "scores": {{ "content": 0, "structure": 0, "coverage": 0, "presentation": 0 }},
  "total": 0,
  "strengths": ["..."],
  "improvements": ["..."],
  "missing_points": ["..."],
  "verdict": "one or two sentence overall assessment"
}}
"total" must be the sum of the four scores, out of 40.
"""
    feedback = ask_gemini(ROLE, prompt, expect_json=True)
    feedback["word_count"] = word_count
    feedback["word_limit"] = word_limit
    feedback["type"] = "evaluation"
    return feedback


def handle(user_input):
    """When routed from free-text, infer the question and evaluate."""
    return evaluate("(Infer the intended question from the answer below.)", user_input, 250)
