"""
Orchestrator — the "brain" that connects everything.

Flow:
  1. Ask the router which specialist should handle the input.
  2. Call that specialist.
  3. Return the answer AND which agent handled it (so the UI can show it).
"""

from . import router, evaluator, tutor, mcq, current_affairs

# Map each agent name to the function that handles it.
AGENTS = {
    "evaluator": evaluator.handle,
    "tutor": tutor.handle,
    "mcq": mcq.handle,
    "current_affairs": current_affairs.handle,
}

# Friendly names for the UI.
LABELS = {
    "evaluator": "Answer Evaluator",
    "tutor": "Tutor",
    "mcq": "MCQ Generator",
    "current_affairs": "Current Affairs",
}


def handle(user_input):
    decision = router.route(user_input)
    agent_name = decision.get("agent", "tutor")
    handler = AGENTS.get(agent_name, tutor.handle)

    data = handler(user_input)

    return {
        "agent": agent_name,
        "agent_label": LABELS.get(agent_name, agent_name),
        "reason": decision.get("reason", ""),
        "data": data,
    }
