"""
Current Affairs agent — explains a current-affairs topic and links it to the
static UPSC syllabus (the skill examiners actually test).

Note: this agent uses the model's own knowledge. For live, up-to-the-day news
you would later connect a news source or web search — that's a future upgrade.
"""

from .gemini_client import ask_gemini

ROLE = (
    "You are a UPSC current-affairs analyst. For any event or news topic, you "
    "explain what it is, why it matters, and — most importantly — link it to the "
    "relevant static syllabus areas (Polity, Economy, Environment, IR, etc.) so "
    "the aspirant knows how it could be asked in Prelims or Mains."
)


def handle(user_input):
    """Return a plain-text analysis linked to the syllabus."""
    prompt = (
        f"{user_input}\n\n"
        "Explain it briefly, then list the static syllabus topics it connects to "
        "and how it might appear in the exam."
    )
    text = ask_gemini(ROLE, prompt)
    return {"type": "text", "title": "Current Affairs — Syllabus Link", "body": text}
